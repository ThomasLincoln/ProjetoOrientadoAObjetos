import java.util.List;

class NullCommand implements Command {
    public void execute(List<String> elements) {
    }
}
